<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php bloginfo('name'); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
<meta name="hello-world/config/environment" content="%7B%22modulePrefix%22%3A%22hello-world%22%2C%22environment%22%3A%22production%22%2C%22baseURL%22%3A%22/%22%2C%22locationType%22%3A%22hash%22%2C%22EmberENV%22%3A%7B%22FEATURES%22%3A%7B%7D%7D%2C%22APP%22%3A%7B%22name%22%3A%22hello-world%22%2C%22version%22%3A%220.0.0+916af264%22%7D%2C%22exportApplicationGlobal%22%3Afalse%7D" />

    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/vendor.css" integrity="sha256-GGgTo7UaTXAE0LHyVNv9W3kPdTbTDeTuuzIMzdcWI7c= sha512-6jecQtvYnlwIJ0IE8M1Hd0UEHyV8w5qWd2rmGxXwOrMsuhy0ScF/+rrcGy38z3lNEHWTumLKKluzdByTaTutOw==" >
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/hello-world.css" integrity="sha256-xd34leORu1M+EncO9ANsNQBThcl4MeEoGz8+4xq92ic= sha512-sonr++nMspcJxKMYRZ9GZaZAEqmISmU61vAHhRXt03geBMZ6Fg16OI1lsQb6wEOONqIJcaq7FOnLlLYOT35CYA==" >

    
  </head>
  <body>
    

    <script src="<?php bloginfo('template_url'); ?>/assets/vendor.js" integrity="sha256-O5mfi61ikxqgEO35mQoYhP7j8JW3fuxp8uUHt0PJ/s0= sha512-xK8LDhpAd69pWMZpSo6Eb/1G3tT9t/anN/A2Zhd4x8dNULcv/1jWqggMrNOHkWQwCXNXKIjA+1rKQNylvYznPQ==" ></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/hello-world.js" integrity="sha256-6ZeSPEBJaI7O9KwZiosO1pxjaEoN9rbSOGPHv0bJxIs= sha512-z1sOdzaNQdAx+GszPAcMowGlatMD8VgsyRyQSIs5RI4RfDjqr9KZWbcekxuYSLJU3MT1OhVRNmkQll8jtVclbg==" ></script>
    
    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>

    
  </body>
</html>
